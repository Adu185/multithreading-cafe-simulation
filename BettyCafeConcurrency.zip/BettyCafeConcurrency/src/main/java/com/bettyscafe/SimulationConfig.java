package com.bettyscafe;

public final class SimulationConfig {

    // Prevent this class from being instantiaed
    private SimulationConfig() {}

    // Controls how fast the simulation runs
    // 1 = slow, 2 = normal, 4 = fast
    public static volatile int speedMultiplier = 2; // default is Normal

    // Shared flag used to start/stop all threads
    // Threads check this so they can exit clenly
    public static volatile boolean running = false;

    // Sleep time adjusted based on current speed setting
    public static void sleepScaled(long baseMs) throws InterruptedException {

        // Make sure multiplier is at least 1 (avoid division by zero)
        int multiplier = Math.max(1, speedMultiplier);

        // Faster speed = smaller slep time
        long scaledTime = Math.max(1, baseMs / multiplier);

        Thread.sleep(scaledTime);
    }
}