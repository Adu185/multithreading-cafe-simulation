package com.bettyscafe;

import java.util.concurrent.Semaphore;

public class Piano {

    // Only 2 customers can play at the same time
    // Fair = first-come-first-served ordering
    private final Semaphore semaphore = new Semaphore(2, true);

    public void play(String customerName) throws InterruptedException {

        // Show intention first (so we can see who is waiting)
        System.out.println(customerName + " wants to play the piano.");

        // Blocks if two people are already playing
        semaphore.acquire();

        try {
            System.out.println(customerName + " is playing the piano.");

            // Random play time between 800 and 2200 ms
            long playTime = 800 + (long) (Math.random() * 1400);

            // Sleep adjusted by simulation speed
            SimulationConfig.sleepScaled(playTime);

            System.out.println(customerName + " finished playing.");

        } finally {
            // Always release permit so someone else can play
            semaphore.release();
        }
    }
}