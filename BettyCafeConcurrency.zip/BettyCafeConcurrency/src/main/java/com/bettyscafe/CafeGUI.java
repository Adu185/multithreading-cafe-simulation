package com.bettyscafe;

import javax.swing.*;
import java.awt.*;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class CafeGUI extends JFrame {

    // Input fields
    private final JTextField customerField = new JTextField("6");
    private final JTextField cakeField = new JTextField("2");
    private final JTextField teaField = new JTextField("2");
    private final JTextField coffeeField = new JTextField("2");

    private final JTextField teaStaffField = new JTextField("1");
    private final JTextField cakeStaffField = new JTextField("1");
    private final JTextField coffeeStaffField = new JTextField("1");

    private final JComboBox<String> speedBox = new JComboBox<>(new String[]{"Slow", "Normal", "Fast"});

    // Buttons
    private final JButton startButton = new JButton("Start");
    private final JButton addCustomerButton = new JButton("Add Customer");
    private final JButton stopButton = new JButton("Stop");
    private final JButton clearLogButton = new JButton("Clear Log");

    // Output area
    private final JTextArea outputArea = new JTextArea(18, 60);

    // Simulation state
    private Buffet buffet;
    private Piano piano;
    private int nextCustomerId = 1;
    private final List<Thread> threads = new ArrayList<>();

    public CafeGUI() {
        setTitle("Betty's Cafe Concurrency Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Basic layoutss
        setLayout(new BorderLayout(10, 10));
        add(buildConfigPanel(), BorderLayout.NORTH);
        add(buildOutputPanel(), BorderLayout.CENTER);
        add(buildButtonPanel(), BorderLayout.SOUTH);

        // Output settings
        speedBox.setSelectedItem("Normal");
        outputArea.setEditable(false);
        outputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        // Rediret System.out / err into the gui text area
        TextAreaOutputStream taOut = new TextAreaOutputStream(outputArea);
        System.setOut(new PrintStream(taOut, true));
        System.setErr(new PrintStream(taOut, true));

        // Button actions
        startButton.addActionListener(e -> startSimulation());
        addCustomerButton.addActionListener(e -> addCustomer());
        stopButton.addActionListener(e -> stopSimulation());
        clearLogButton.addActionListener(e -> outputArea.setText(""));

        // Allow speed changes during execution (updates SimultionConfig live)
        speedBox.addActionListener(e -> applySpeed());

        setRunningUI(false);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // UI building

    private JPanel buildConfigPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 4, 8, 6));
        panel.setBorder(BorderFactory.createTitledBorder("Configuration"));

        panel.add(new JLabel("Customers:"));
        panel.add(customerField);
        panel.add(new JLabel("Speed:"));
        panel.add(speedBox);

        panel.add(new JLabel("Initial Cakes:"));
        panel.add(cakeField);
        panel.add(new JLabel("Tea Staff:"));
        panel.add(teaStaffField);

        panel.add(new JLabel("Initial Teas:"));
        panel.add(teaField);
        panel.add(new JLabel("Cake Staff:"));
        panel.add(cakeStaffField);

        panel.add(new JLabel("Initial Coffees:"));
        panel.add(coffeeField);
        panel.add(new JLabel("Coffee Staff:"));
        panel.add(coffeeStaffField);

        // Padding row
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));
        panel.add(new JLabel(""));

        return panel;
    }

    private JScrollPane buildOutputPanel() {
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Simulation Output"));
        return scrollPane;
    }

    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.add(startButton);
        panel.add(addCustomerButton);
        panel.add(stopButton);
        panel.add(clearLogButton);
        return panel;
    }

    // Simulation control

    private void startSimulation() {
        if (SimulationConfig.running) return;

        try {
            // Read values from the text fields
            Config cfg = readConfig();

            // Apply speed multiplier based on combo box
            applySpeed();

            // Reset simulation state
            SimulationConfig.running = true;
            threads.clear();
            nextCustomerId = 1;

            buffet = new Buffet(cfg.cakes, cfg.teas, cfg.coffees);
            piano = new Piano();

            System.out.println("Starting program with " + cfg.customers + " clients.");
            buffet.printStatus();

            // Start customer threads
            for (int i = 0; i < cfg.customers; i++) {
                startThread(new Customer("Client-" + nextCustomerId++, buffet, piano));
            }

            // Start staff threads (counts are confiurable)
            for (int i = 1; i <= cfg.teaStaff; i++) startThread(new Staff("Staff-Tea-" + i, buffet, "tea"));
            for (int i = 1; i <= cfg.cakeStaff; i++) startThread(new Staff("Staff-Cake-" + i, buffet, "cake"));
            for (int i = 1; i <= cfg.coffeeStaff; i++) startThread(new Staff("Staff-Coffee-" + i, buffet, "coffee"));

            setRunningUI(true);
            System.out.println("Simulation started successfully.");

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addCustomer() {
        if (!SimulationConfig.running || buffet == null || piano == null) return;

        String name = "Client-" + nextCustomerId++;
        System.out.println("Adding new customer dynamically: " + name);
        startThread(new Customer(name, buffet, piano));
    }

    private void stopSimulation() {
        if (!SimulationConfig.running) return;

        System.out.println("Stopping simulation...");
        SimulationConfig.running = false;

        // Wake up customers that might be waiting on the buffet
        if (buffet != null) buffet.signalAllWaiters();

        // Interrupt everything so sleeps end quickly
        for (Thread t : threads) {
            try {
                t.interrupt();
            } catch (Exception ignored) { }
        }

        setRunningUI(false);
        System.out.println("Simulation stopped.");
    }

    private void startThread(Thread t) {
        threads.add(t);
        t.start();
    }

    // Enable/disable GUI controls depending on weather simulation is running
    private void setRunningUI(boolean running) {
        startButton.setEnabled(!running);
        addCustomerButton.setEnabled(running);
        stopButton.setEnabled(running);

        // Lock config fields while running (prevents chaning initial values mid-run)
        customerField.setEnabled(!running);
        cakeField.setEnabled(!running);
        teaField.setEnabled(!running);
        coffeeField.setEnabled(!running);

        teaStaffField.setEnabled(!running);
        cakeStaffField.setEnabled(!running);
        coffeeStaffField.setEnabled(!running);

        speedBox.setEnabled(true);
    }

    // Read all config values from GUI fields
    private Config readConfig() {
        int customers = parsePositive(customerField.getText(), "Customers");
        int cakes = parseNonNegative(cakeField.getText(), "Initial Cakes");
        int teas = parseNonNegative(teaField.getText(), "Initial Teas");
        int coffees = parseNonNegative(coffeeField.getText(), "Initial Coffees");

        int teaStaff = parseNonNegative(teaStaffField.getText(), "Tea Staff");
        int cakeStaff = parseNonNegative(cakeStaffField.getText(), "Cake Staff");
        int coffeeStaff = parseNonNegative(coffeeStaffField.getText(), "Coffee Staff");

        return new Config(customers, cakes, teas, coffees, teaStaff, cakeStaff, coffeeStaff);
    }

    // Set speed multiplier based on the combo box
    private void applySpeed() {
        String speed = (String) speedBox.getSelectedItem();

        if ("Slow".equals(speed)) SimulationConfig.speedMultiplier = 1;
        else if ("Normal".equals(speed)) SimulationConfig.speedMultiplier = 2;
        else SimulationConfig.speedMultiplier = 4;
    }

    // Small struct-like class so we can pass config around cleanly
    private static class Config {
        final int customers, cakes, teas, coffees;
        final int teaStaff, cakeStaff, coffeeStaff;

        Config(int customers, int cakes, int teas, int coffees,
               int teaStaff, int cakeStaff, int coffeeStaff) {
            this.customers = customers;
            this.cakes = cakes;
            this.teas = teas;
            this.coffees = coffees;
            this.teaStaff = teaStaff;
            this.cakeStaff = cakeStaff;
            this.coffeeStaff = coffeeStaff;
        }
    }

    // parsing helpers

    private static int parsePositive(String text, String label) {
        int v = Integer.parseInt(text.trim());
        if (v <= 0) throw new IllegalArgumentException(label + " must be > 0");
        return v;
    }

    private static int parseNonNegative(String text, String label) {
        int v = Integer.parseInt(text.trim());
        if (v < 0) throw new IllegalArgumentException(label + " must be >= 0");
        return v;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CafeGUI::new);
    }
}