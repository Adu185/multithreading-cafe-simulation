package com.bettyscafe;

import java.util.Random;

public class Customer extends Thread {

    private final Buffet buffet;
    private final Piano piano;
    private final Random random = new Random();

    public Customer(String name, Buffet buffet, Piano piano) {
        super(name);
        this.buffet = buffet;
        this.piano = piano;
    }

    @Override
    public void run() {
        try {
            while (SimulationConfig.running && !isInterrupted()) {

                int choice = random.nextInt(7);

                switch (choice) {
                    case 0 -> eatOrDrink("cake", 1, 0, 0, 1200);
                    case 1 -> eatOrDrink("tea", 0, 1, 0, 1000);
                    case 2 -> eatOrDrink("coffee", 0, 0, 1, 1000);
                    case 3 -> eatOrDrink("tea and cake", 1, 1, 0, 1500);
                    case 4 -> eatOrDrink("coffee and cake", 1, 0, 1, 1500);
                    case 5 -> listenToMusic();
                    case 6 -> piano.play(getName());
                }

                // Small pause between activities so output is easier to follow
                SimulationConfig.sleepScaled(800);
            }
        } catch (InterruptedException e) {
            // If someone interrupts this thread, stop cleanly
            interrupt();
        }
    }

    // Customer tries to take items, then "uses" themm for a random-ish time
    private void eatOrDrink(String wantText, int cake, int tea, int coffee, int actionMs)
            throws InterruptedException {

        System.out.println(getName() + " wants " + wantText + ".");

        // This blocks if the buufet doesn't have enough items yet
        buffet.takeItems(cake, tea, coffee, getName());

        // If simulation was stiopped while waiting, exit early
        if (!SimulationConfig.running) return;

        System.out.println(getName() + " has " + wantText + ".");
        SimulationConfig.sleepScaled(actionMs);
        System.out.println(getName() + " finished " + wantText + ".");
    }

    private void listenToMusic() throws InterruptedException {
        System.out.println(getName() + " listens to music.");
        SimulationConfig.sleepScaled(1500);
        System.out.println(getName() + " finished listening to music.");
    }
}