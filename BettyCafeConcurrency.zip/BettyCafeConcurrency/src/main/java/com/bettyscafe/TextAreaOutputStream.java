package com.bettyscafe;

import javax.swing.*;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class TextAreaOutputStream extends OutputStream {

    private final JTextArea textArea;

    // Temporary buffeer to collect characters before printing
    private final StringBuilder buffer = new StringBuilder();

    public TextAreaOutputStream(JTextArea textArea) {
        this.textArea = textArea;
    }

    // Called when a single charcter is written
    @Override
    public void write(int b) {
        char c = (char) b;
        buffer.append(c);

        // If we hit a newline, push text to the GUI
        if (c == '\n') {
            flushBuffer();
        }
    }

    // Called when multiple bytes are written at once
    @Override
    public void write(byte[] b, int off, int len) {
        buffer.append(new String(b, off, len, StandardCharsets.UTF_8));

        // If buffer contains a newline, update the GUI
        if (buffer.indexOf("\n") >= 0) {
            flushBuffer();
        }
    }

    @Override
    public void flush() {
        flushBuffer();
    }

    // Sends bufferd text safely to the JTextArea
    private void flushBuffer() {
        if (buffer.length() == 0) return;

        final String text = buffer.toString();
        buffer.setLength(0);

        // Swing updates must run on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            textArea.append(text);

            // Auto-scroll to bottom
            textArea.setCaretPosition(textArea.getDocument().getLength());
        });
    }
}