package com.bettyscafe;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Buffet {

    private int cakes;
    private int teas;
    private int coffees;

    // One fair lock protects all buffet items
    // Using one lock avoids deadlock from multiple locks
    private final ReentrantLock lock = new ReentrantLock(true);

    // Customers wait on this condtion if items are unavailable
    private final Condition itemsAvailable = lock.newCondition();

    public Buffet(int cakes, int teas, int coffees) {
        this.cakes = cakes;
        this.teas = teas;
        this.coffees = coffees;
    }

    // Called by customers when they want to take itms
    public void takeItems(int cakeNeeded, int teaNeeded, int coffeeNeeded, String customerName)
            throws InterruptedException {

        lock.lock(); // enters a critical section
        try {

            // Wait while simulation is running and we dont have enough stock
            while (SimulationConfig.running &&
                    (cakes < cakeNeeded || teas < teaNeeded || coffees < coffeeNeeded)) {

                System.out.println(customerName + " waits (needs " +
                        describe(cakeNeeded, teaNeeded, coffeeNeeded) + ").");

                // Timed wait which allows thread to wake up if simulation stops
                itemsAvailable.await(500, TimeUnit.MILLISECONDS);
            }

            // If simulation has been stopped, exit without taking items
            if (!SimulationConfig.running) return;

            // Reduce stock (safe because we are inside the lock)
            cakes -= cakeNeeded;
            teas -= teaNeeded;
            coffees -= coffeeNeeded;

            System.out.println(customerName + " takes " +
                    describe(cakeNeeded, teaNeeded, coffeeNeeded) + ".");
            printStatus();

        } finally {
            lock.unlock(); // leave critical section
        }
    }

    // Called by staff when they refill items
    public void addItems(int cake, int tea, int coffee, String staffName) {

        lock.lock(); // enter critical section
        try {
            cakes += cake;
            teas += tea;
            coffees += coffee;

            System.out.println(staffName + " refills buffet (adds " +
                    describe(cake, tea, coffee) + ").");
            printStatus();

            // Wake up all waiting customers so they can check stock again
            itemsAvailable.signalAll();

        } finally {
            lock.unlock(); // leave critical section
        }
    }

    // Used when stopping the simulation to wake up any waiting threads
    public void signalAllWaiters() {
        lock.lock();
        try {
            itemsAvailable.signalAll();
        } finally {
            lock.unlock();
        }
    }

    // Helper method to format item descriptions for output
    private static String describe(int cakes, int teas, int coffees) {

        String result = "";

        if (cakes > 0) {
            result += cakes + " cake" + (cakes == 1 ? "" : "s");
        }

        if (teas > 0) {
            if (!result.isEmpty()) result += " and ";
            result += teas + " tea" + (teas == 1 ? "" : "s");
        }

        if (coffees > 0) {
            if (!result.isEmpty()) result += " and ";
            result += coffees + " coffee" + (coffees == 1 ? "" : "s");
        }

        return result.isEmpty() ? "nothing" : result;
    }

    // Prints current buffet stock
    public void printStatus() {
        System.out.println("Buffet = (" +
                cakes + " cakes, " +
                teas + " teas, " +
                coffees + " coffees)");
    }
}