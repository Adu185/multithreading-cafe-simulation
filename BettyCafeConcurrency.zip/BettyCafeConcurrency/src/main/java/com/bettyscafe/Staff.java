package com.bettyscafe;

import java.util.Random;

public class Staff extends Thread {

    private final Buffet buffet;
    private final String type; // "tea", "cofee", or "cake"
    private final Random random = new Random();

    public Staff(String name, Buffet buffet, String type) {
        super(name);
        this.buffet = buffet;
        this.type = type;
    }

    @Override
    public void run() {
        try {
            while (SimulationConfig.running && !isInterrupted()) {

                // Wait a bit beofre make the next refill (simulates being busy)
                SimulationConfig.sleepScaled(3000);

                // Staff brings 1 to 3 items at a time
                int amount = random.nextInt(3) + 1;

                System.out.println(getName() + " prepares " + amount + " " + type + "(s) in kitchen.");
                SimulationConfig.sleepScaled(600);

                // Add the correct item type to the buffet
                addToBuffet(amount);

                System.out.println(getName() + " returns to kitchen.");
            }
        } catch (InterruptedException e) {
            // Stop cleanly if interrpetd
            interrupt();
        }
    }

    // Small helper method so run() stays easy to read
    private void addToBuffet(int amount) {
        switch (type) {
            case "tea" -> buffet.addItems(0, amount, 0, getName());
            case "coffee" -> buffet.addItems(0, 0, amount, getName());
            case "cake" -> buffet.addItems(amount, 0, 0, getName());
            default -> System.out.println(getName() + " has unknown staff type: " + type);
        }
    }
}